SPECTACULAR_SETTINGS = {
    'TITLE': 'simpleblog API',
    'VERSION': '1.0.0',
    'SERVE_INCLUDE_SCHEMA': False,
}

